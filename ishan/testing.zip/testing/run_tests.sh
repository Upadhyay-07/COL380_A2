#!/usr/bin/env bash
# ============================================================
# run_tests.sh
# ============================================================
# Builds the project, runs all test inputs through knn,
# approx_knn, and kmeans, saves outputs per test, and
# computes MAE(knn, approx_knn) for every test case.
#
# Usage (from the a2/ directory):
#   bash run_tests.sh
#
# Outputs:
#   tests/outputs/<test_name>/knn.txt
#   tests/outputs/<test_name>/approx_knn.txt
#   tests/outputs/<test_name>/kmeans.txt
#   tests/outputs/mae_summary.txt   ← MAE for every test
#   tests/outputs/run_summary.txt   ← pass/fail for every test
# ============================================================

set -euo pipefail

# ── Paths ─────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUTS_DIR="$SCRIPT_DIR/tests/inputs"
OUTPUTS_DIR="$SCRIPT_DIR/tests/outputs"
BINARY="$SCRIPT_DIR/a2"
MAE_SCRIPT="$SCRIPT_DIR/mae_loss.py"
MAE_SUMMARY="$OUTPUTS_DIR/mae_summary.txt"
RUN_SUMMARY="$OUTPUTS_DIR/run_summary.txt"

mkdir -p "$OUTPUTS_DIR"

# ── Colours (graceful degradation if not a terminal) ──────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
if [ ! -t 1 ]; then RED=''; GREEN=''; YELLOW=''; CYAN=''; BOLD=''; RESET=''; fi

# ── Step 1 : Build ────────────────────────────────────────────
echo -e "${BOLD}${CYAN}=== Step 1: Building project ===${RESET}"
cd "$SCRIPT_DIR"
if make 2>&1; then
    echo -e "${GREEN}  Build succeeded.${RESET}"
else
    echo -e "${RED}  Build FAILED. Fix compilation errors before running tests.${RESET}"
    exit 1
fi
echo ""

# ── Step 2 : Run tests ────────────────────────────────────────
echo -e "${BOLD}${CYAN}=== Step 2: Running tests ===${RESET}"

# Collect all input files, sorted
mapfile -t INPUT_FILES < <(ls "$INPUTS_DIR"/*.txt 2>/dev/null | sort)

if [ ${#INPUT_FILES[@]} -eq 0 ]; then
    echo -e "${RED}No test input files found in $INPUTS_DIR.${RESET}"
    echo "Run:  python3 generate_tests.py  first."
    exit 1
fi

PASS=0; FAIL=0
declare -A TEST_STATUS        # test_name -> PASS|FAIL
declare -A SKIP_MAE           # test_name -> 1 if MAE should be skipped

# Header for run summary
{
    printf "%-35s %-10s %-10s %-10s %s\n" "TEST" "KNN" "APPROX_KNN" "KMEANS" "NOTES"
    printf '%0.s-' {1..90}; echo
} > "$RUN_SUMMARY"

for INPUT_FILE in "${INPUT_FILES[@]}"; do
    TEST_NAME="$(basename "$INPUT_FILE" .txt)"
    TEST_OUT_DIR="$OUTPUTS_DIR/$TEST_NAME"
    mkdir -p "$TEST_OUT_DIR"

    KNN_OUT="$TEST_OUT_DIR/knn.txt"
    APPROX_OUT="$TEST_OUT_DIR/approx_knn.txt"
    KMEANS_OUT="$TEST_OUT_DIR/kmeans.txt"

    STATUS_KNN="PASS"; STATUS_APPROX="PASS"; STATUS_KMEANS="PASS"
    NOTES=""
    ANY_FAIL=0

    printf "  %-35s " "$TEST_NAME"

    # -- knn --
    if "$BINARY" "$INPUT_FILE" knn > /dev/null 2>&1; then
        mv -f "$SCRIPT_DIR/knn.txt" "$KNN_OUT"
    else
        STATUS_KNN="FAIL"; ANY_FAIL=1
        NOTES+="knn-error "
    fi

    # -- approx_knn --
    if "$BINARY" "$INPUT_FILE" approx_knn > /dev/null 2>&1; then
        mv -f "$SCRIPT_DIR/approx_knn.txt" "$APPROX_OUT"
    else
        STATUS_APPROX="FAIL"; ANY_FAIL=1
        NOTES+="approx_knn-error "
    fi

    # -- kmeans --
    if "$BINARY" "$INPUT_FILE" kmeans > /dev/null 2>&1; then
        mv -f "$SCRIPT_DIR/kmeans.txt" "$KMEANS_OUT"
    else
        STATUS_KMEANS="FAIL"; ANY_FAIL=1
        NOTES+="kmeans-error "
    fi

    if [ $ANY_FAIL -eq 0 ]; then
        echo -e "${GREEN}PASS${RESET}"
        TEST_STATUS["$TEST_NAME"]="PASS"
        PASS=$((PASS + 1))
    else
        echo -e "${RED}FAIL${RESET} ($NOTES)"
        TEST_STATUS["$TEST_NAME"]="FAIL"
        SKIP_MAE["$TEST_NAME"]=1
        FAIL=$((FAIL + 1))
    fi

    printf "%-35s %-10s %-10s %-10s %s\n" \
        "$TEST_NAME" "$STATUS_KNN" "$STATUS_APPROX" "$STATUS_KMEANS" "$NOTES" \
        >> "$RUN_SUMMARY"
done

echo ""
echo -e "  Results: ${GREEN}${PASS} passed${RESET}  ${RED}${FAIL} failed${RESET}"
echo ""

# ── Step 3 : MAE(knn vs approx_knn) ──────────────────────────
echo -e "${BOLD}${CYAN}=== Step 3: Computing MAE (knn vs approx_knn) ===${RESET}"

{
    printf "%-35s %s\n" "TEST" "MAE"
    printf '%0.s-' {1..55}; echo
} > "$MAE_SUMMARY"

printf "  %-35s %s\n" "TEST" "MAE"
printf "  "; printf '%0.s-' {1..50}; echo

for INPUT_FILE in "${INPUT_FILES[@]}"; do
    TEST_NAME="$(basename "$INPUT_FILE" .txt)"
    TEST_OUT_DIR="$OUTPUTS_DIR/$TEST_NAME"
    KNN_OUT="$TEST_OUT_DIR/knn.txt"
    APPROX_OUT="$TEST_OUT_DIR/approx_knn.txt"

    if [ "${SKIP_MAE[$TEST_NAME]+_}" ]; then
        printf "  %-35s %s\n" "$TEST_NAME" "SKIPPED (run error)"
        printf "%-35s %s\n" "$TEST_NAME" "SKIPPED (run error)" >> "$MAE_SUMMARY"
        continue
    fi

    if [ ! -f "$KNN_OUT" ] || [ ! -f "$APPROX_OUT" ]; then
        printf "  %-35s %s\n" "$TEST_NAME" "SKIPPED (output missing)"
        printf "%-35s %s\n" "$TEST_NAME" "SKIPPED (output missing)" >> "$MAE_SUMMARY"
        continue
    fi

    MAE_VAL="$(python3 "$MAE_SCRIPT" "$KNN_OUT" "$APPROX_OUT" 2>&1 | awk '{print $2}')" || MAE_VAL="ERROR"
    printf "  %-35s %s\n" "$TEST_NAME" "$MAE_VAL"
    printf "%-35s %s\n"   "$TEST_NAME" "$MAE_VAL" >> "$MAE_SUMMARY"
done

echo ""

# ── Step 4 : Summary ──────────────────────────────────────────
echo -e "${BOLD}${CYAN}=== Step 4: Summary ===${RESET}"
TOTAL=${#INPUT_FILES[@]}
echo -e "  Total tests  : ${BOLD}${TOTAL}${RESET}"
echo -e "  Passed       : ${GREEN}${PASS}${RESET}"
echo -e "  Failed       : ${RED}${FAIL}${RESET}"
echo ""
echo -e "  Run summary  : ${BOLD}tests/outputs/run_summary.txt${RESET}"
echo -e "  MAE summary  : ${BOLD}tests/outputs/mae_summary.txt${RESET}"
echo -e "  Per-test outs: ${BOLD}tests/outputs/<test_name>/{knn,approx_knn,kmeans}.txt${RESET}"
echo ""

if [ $FAIL -gt 0 ]; then
    echo -e "${YELLOW}  Warning: ${FAIL} test(s) failed. Check run_summary.txt for details.${RESET}"
    exit 1
fi

echo -e "${GREEN}  All tests passed.${RESET}"
